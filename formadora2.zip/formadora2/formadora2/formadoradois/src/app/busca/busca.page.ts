import { Component } from '@angular/core';
import { RouterLink } from '@angular/router'; 
import { IonHeader, IonToolbar, IonTitle, IonContent,IonButton , IonInput, IonItem, IonLabel,  } from '@ionic/angular/standalone';  

@Component({
  selector: 'app-busca',
  standalone: true,
  templateUrl: 'busca.page.html',
  styleUrls: ['busca.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonInput, IonItem, IonLabel, IonButton, RouterLink], 
})
export class BuscaPage {
  constructor() {}
}

