import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButton, IonList, IonItem, IonImg } from '@ionic/angular/standalone';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-busca',
  standalone: true,
  templateUrl: 'busca.page.html',
  styleUrls: ['busca.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonButton, IonList, IonItem, IonImg, RouterLink, CommonModule, HttpClientModule],
})
export class BuscaPage {
  public dogs: string[] = [];

  constructor(private http: HttpClient) {}

  carregarDogs() {
    this.http.get('https://dog.ceo/api/breeds/image/random/10')
      .subscribe((res: any) => {
        this.dogs = res.message; 
      });
  }
}
